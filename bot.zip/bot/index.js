var Discord = require('discord.js');
var sets = require('./settings.json');
var client = new Discord.Client({
    owner: sets.ownerid
});

client.login(sets.prefix);
console.log("Bot Hazır!");

client.on("message",message => {
    if (message.author.bot) return;
    if (message.channel.type === "dm") return;
    var parsedStr = message.content.split(" ");
    var cmd = parsedStr[0];

    // sil komutu
    if (cmd === `${sets.prefix}sil`) {
        if (!message.member.hasPermission('MANAGE_MESSAGES')) return message.reply("Bu komutu kullanabilmek için `MESAJLARI YÖNET` yetkisine sahip olmanız gerekir.");
        let sayı = parsedStr[1];
        if (!sayı) return message.reply("Mesajları silebilmem için bir sayı belirtmen gerekir.");
        message.channel.bulkDelete(sayı).then(()=>{
            message.reply(`**${sayı}** Mesaj Silindi.`)
            .then(msg => msg.delete({timeout:5000}));
        }).catch(error => {
            console.log(error);
            message.reply("Bir Hata Oluştu.");
        });
    }

    // ping
    if (cmd === `${sets.prefix}ping`) message.reply(`Mesaj Gecikmesi: **${Date.now() - message.createdTimestamp} ms.** Bot/API Gecikmesi: **${Math.round(client.ws.ping)}**`);

    // sa-as sistemi
    if (message.content==="sa"||message.content==="SA"||message.content==="Sa"||message.content==="sA"||message.content==="Selam"||message.content==="selam"||message.content==="SELAM"||message.content==="selamın aleyküm"||message.content==="Selamın Aleyküm"||message.content==="SELAMIN ALEYKÜM"||message.content==="Selamın aleyküm"||message.content==="selamın Aleyküm") message.reply("Aleyküm Selam Hoşgeldin!");

    // kayıt (Örnek: Emir | 14) (Kullanımı: !kayıt isim yaş erkek/dişi)
    var regChannel = "KANAL ID"; // Kanal ID = İnsanların kayıt olabileceği kanal
    if (message.channel.id===regChannel) {
        if (cmd===`${sets.prefix}kayıt`) {
            if (!parsedStr[1]) {
                message.reply("Kayıt olabilmek için **ismini** belirtmen gerekir.")
                .then(msg => msg.delete({timeout:5000}));
                message.delete();
            }
            if (!parsedStr[2]) {
                message.reply("Kayıt olabilmek için **yaşını** belirtmen gerekir.")
                .then(msg => msg.delete({timeout:5000}));
                message.delete();
            }
            if (!parsedStr[3]) {
                message.reply("Kayıt olabilmek için **cinsiyetini** belirtmen gerekir.")
                .then(msg => msg.delete({timeout:5000}));
                message.delete();
            }
            var maleRole = "Rol ID"; // male = erkek
            var femaleRole = "Rol ID"; // female = dişi/kadın/bayan (her neyse)
            if (parsedStr[3] === "erkek") message.member.roles.add(maleRole);
            if (parsedStr[3] === "dişi") message.member.roles.add(femaleRole);
            message.member.setNickname(`${parsedStr[1]} | ${parsedStr[2]}`);
            var memberRole = "Rol ID"; // member role = üye rolü
            message.member.roles.add(memberRole).then(()=>{
                console.log("[SERVER/SIGNUP] Yeni Bir Üye Katıldı!");
                message.delete();
            }).catch(err => {
                console.log(err);
                message.reply("Bir Hata Oluştu.")
                .then(msg => msg.delete({timeout:5000}));
                message.delete();
            });
         }
    }
});

// Made In Turkey
// From Gamers TR
// All rights reserved.
// Copyright 2021 Gamers TR